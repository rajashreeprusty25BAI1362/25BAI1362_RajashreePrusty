# MealBridge FastAPI - AI Agent Guidance

## Project Overview

**MealBridge** is a FastAPI-based API for managing food donations and volunteers. The application connects food donors with volunteers to redistribute surplus food to communities in need.

**Tech Stack:**
- **Framework:** FastAPI (Python)
- **Database:** MongoDB
- **Environment:** Python virtual environment (venv)

## Architecture

### Core Components

1. **main.py** - FastAPI application entry point
   - Initializes the FastAPI app
   - Defines API endpoints for donors, volunteers, and donations
   - Current endpoints: `GET /`, `GET /check-db`

2. **database.py** - MongoDB connection and data layer
   - Establishes MongoDB connection using MONGO_URL
   - Defines three main collections:
     - `donors` - Food source organizations/individuals
     - `volunteers` - People coordinating food distribution
     - `food_donations` - Records of available food items

3. **.env** - Environment configuration
   - `MONGO_URL` - MongoDB connection string (default: `mongodb://localhost:27017/`)
   - `DB_NAME` - Database name (`mealbridge_db`)

## Development Workflow

### Running the Application
```bash
# Activate virtual environment
./venv/Scripts/activate

# Run the server
python main.py
# OR
uvicorn main:app --reload
```

### Testing Database Connection
- Use `GET /check-db` endpoint to verify MongoDB is running and connected

## API Design Conventions

### Endpoint Patterns
- Use FastAPI route decorators: `@app.get()`, `@app.post()`, `@app.put()`, `@app.delete()`
- RESTful routes: `/donors`, `/volunteers`, `/donations`
- Return JSON responses with consistent structure: `{"message": "...", "data": {...}}` or `{"error": "..."}`

### Error Handling
- Wrap database operations in try-except blocks
- Return error objects with meaningful messages
- Example: `{"error": str(e)}`

### Data Collections
When adding new endpoints, follow these patterns:

**Donors Collection:**
- Fields: `name`, `location`, `contact`, `food_items` (array), `created_at`

**Volunteers Collection:**
- Fields: `name`, `location`, `contact`, `availability`, `skills`, `created_at`

**Food Donations Collection:**
- Fields: `donor_id`, `food_type`, `quantity`, `expiry_date`, `pickup_location`, `volunteer_id`, `status`, `created_at`

## Common Development Tasks

### Adding a New Endpoint
1. Import necessary modules at top of main.py
2. Define endpoint with proper HTTP method and route
3. Add request validation using Pydantic models (optional but recommended)
4. Implement error handling with try-except
5. Return appropriate JSON response

### Database Queries
- Access collections via: `from database import donor_collection, volunteer_collection, donation_collection`
- Use PyMongo methods: `insert_one()`, `find_one()`, `find()`, `update_one()`, `delete_one()`
- Convert MongoDB ObjectId to string for JSON serialization

### Environment Setup
- Ensure MongoDB is running locally before starting the app
- Load environment variables from .env using `python-dotenv`
- Never commit .env file with sensitive data to version control

## File Structure (Current)
```
MealBridgeFastAPI/
├── main.py              # FastAPI app and endpoints
├── database.py          # MongoDB connection setup
├── .env                 # Environment variables (local only)
├── venv/               # Python virtual environment
└── __pycache__/        # Python cache (ignore)
```

# MealBridge API Endpoints

Base URL:

```text
http://127.0.0.1:8000
```

Note: These are local API links, so they use `http`, not `https`.

---

## System APIs

### 1. Home API

```text
GET http://127.0.0.1:8000/
```

Purpose: Checks whether the MealBridge API is running.

---

### 2. Check MongoDB Connection

```text
GET http://127.0.0.1:8000/check-db
```

Purpose: Checks whether FastAPI is connected to MongoDB.

---

## Donor APIs

### 3. Add Donor

```text
POST http://127.0.0.1:8000/donors
```

Body:

```json
{
  "name": "Neha Gupta",
  "email": "neha@gmail.com",
  "phone": "9876501234",
  "address": "Mumbai"
}
```

---

### 4. View All Donors

```text
GET http://127.0.0.1:8000/donors
```

---

### 5. View Donor by ID

```text
GET http://127.0.0.1:8000/donors/{donor_id}
```

Example:

```text
GET http://127.0.0.1:8000/donors/PASTE_DONOR_ID_HERE
```

---

### 6. Update Donor

```text
PUT http://127.0.0.1:8000/donors/{donor_id}
```

Body:

```json
{
  "name": "Neha Gupta",
  "email": "neha.updated@gmail.com",
  "phone": "9876501234",
  "address": "Pune"
}
```

---

### 7. Delete Donor

```text
DELETE http://127.0.0.1:8000/donors/{donor_id}
```

---

## Volunteer APIs

### 8. Add Volunteer

```text
POST http://127.0.0.1:8000/volunteers
```

Body:

```json
{
  "name": "Aman Verma",
  "email": "aman@gmail.com",
  "phone": "9123456780",
  "area": "Mumbai",
  "availability": "Available"
}
```

---

### 9. View All Volunteers

```text
GET http://127.0.0.1:8000/volunteers
```

---

### 10. View Volunteer by ID

```text
GET http://127.0.0.1:8000/volunteers/{volunteer_id}
```

Example:

```text
GET http://127.0.0.1:8000/volunteers/PASTE_VOLUNTEER_ID_HERE
```

---

### 11. Update Volunteer

```text
PUT http://127.0.0.1:8000/volunteers/{volunteer_id}
```

Body:

```json
{
  "name": "Aman Verma",
  "email": "aman.updated@gmail.com",
  "phone": "9123456780",
  "area": "Delhi",
  "availability": "Available"
}
```

---

### 12. Delete Volunteer

```text
DELETE http://127.0.0.1:8000/volunteers/{volunteer_id}
```

---

## Food Donation APIs

### 13. Add Food Donation

```text
POST http://127.0.0.1:8000/donations
```

Body:

```json
{
  "donor_id": "6a2d894ee26563429d54d090",
  "food_type": "Rice and Dal",
  "quantity": "25 plates",
  "pickup_location": "Mumbai Hostel Canteen",
  "pickup_time": "7:30 PM",
  "expiry_time": "10:30 PM",
  "status": "Available",
  "volunteer_id": null
}
```

---

### 14. View All Donations

```text
GET http://127.0.0.1:8000/donations
```

---

### 15. View Available Donations

```text
GET http://127.0.0.1:8000/donations/available
```

---

### 16. View Donation by ID

```text
GET http://127.0.0.1:8000/donations/{donation_id}
```

Example:

```text
GET http://127.0.0.1:8000/donations/PASTE_DONATION_ID_HERE
```

---

### 17. Update Donation

```text
PUT http://127.0.0.1:8000/donations/{donation_id}
```

Body:

```json
{
  "donor_id": "6a2d894ee26563429d54d090",
  "food_type": "Chapati and Sabzi",
  "quantity": "30 plates",
  "pickup_location": "College Canteen",
  "pickup_time": "8:00 PM",
  "expiry_time": "11:00 PM",
  "status": "Available",
  "volunteer_id": null
}
```

---

### 18. Assign Volunteer to Donation

```text
PUT http://127.0.0.1:8000/donations/{donation_id}/assign-volunteer/{volunteer_id}
```

Example:

```text
PUT http://127.0.0.1:8000/donations/PASTE_DONATION_ID_HERE/assign-volunteer/PASTE_VOLUNTEER_ID_HERE
```

No body is required.

---

### 19. Update Donation Status

```text
PUT http://127.0.0.1:8000/donations/{donation_id}/status
```

Body:

```json
{
  "status": "Delivered"
}
```

---

### 20. Delete Donation

```text
DELETE http://127.0.0.1:8000/donations/{donation_id}
```

---

## Search API

### 21. Search Donations by Food Type

```text
GET http://127.0.0.1:8000/search-donations/{food_type}
```

Example:

```text
GET http://127.0.0.1:8000/search-donations/Rice
```

---

## Delete Operation

### 22. Clear All Donation Records

```text
DELETE http://127.0.0.1:8000/clear-donations
```

Purpose: Deletes all records from the food donations collection.

Use carefully because it removes all donation data.


## Next Steps for AI Agents

When contributing to this project:
1. **Understand the context:** This is a food donation coordination platform
2. **Check MongoDB collections:** Reference the structure above for new queries
3. **Follow REST conventions:** Consistent endpoint design across donors, volunteers, and donations
4. **Add error handling:** All database operations should have try-except blocks
5. **Test database connectivity:** Verify MongoDB is running before testing endpoints
6. **Use meaningful variable names:** `donor_id`, `volunteer_id`, `donation_status` for clarity

## Dependencies
- FastAPI - Web framework
- Uvicorn - ASGI server
- PyMongo - MongoDB Python driver
- python-dotenv - Environment variable management

