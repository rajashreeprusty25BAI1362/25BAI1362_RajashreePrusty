from pymongo import MongoClient
from dotenv import load_dotenv
import os

load_dotenv()

MONGO_URL = os.getenv("MONGO_URL")
DB_NAME = os.getenv("DB_NAME")

client = MongoClient(MONGO_URL, serverSelectionTimeoutMS=5000)
database = client[DB_NAME]

donor_collection = database["donors"]
volunteer_collection = database["volunteers"]
donation_collection = database["food_donations"]
user_collection = database["users"]