const API_URL = "http://127.0.0.1:8000";

function checkBackend() {
    fetch(`${API_URL}/`)
        .then(response => response.json())
        .then(data => {
            document.getElementById("backendResult").innerText =
                JSON.stringify(data);
        })
        .catch(error => {
            document.getElementById("backendResult").innerText =
                "Backend connection failed";
            console.log(error);
        });
}

// ---------------- DONOR FUNCTIONS ----------------

function addDonor() {
    const name = document.getElementById("donorName").value.trim();
    const email = document.getElementById("donorEmail").value.trim();
    const phone = document.getElementById("donorPhone").value.trim();
    const address = document.getElementById("donorAddress").value.trim();

    if (name === "" || email === "" || phone === "" || address === "") {
        document.getElementById("donorResult").innerText =
            "Please fill all donor fields before adding.";
        return;
    }

    const donor = {
        name: name,
        email: email,
        phone: phone,
        address: address
    };

    fetch(`${API_URL}/donors`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(donor)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to add donor");
        }
        return response.json();
    })
    .then(data => {
        document.getElementById("donorResult").innerText =
            "Donor added successfully!";

        document.getElementById("donorName").value = "";
        document.getElementById("donorEmail").value = "";
        document.getElementById("donorPhone").value = "";
        document.getElementById("donorAddress").value = "";

        getDonors();
    })
    .catch(error => {
        document.getElementById("donorResult").innerText =
            "Error adding donor. Please check backend.";
        console.log(error);
    });
}

function getDonors() {
    fetch(`${API_URL}/donors`)
        .then(response => response.json())
        .then(data => {
            const list = document.getElementById("donorsList");
            list.innerHTML = "";

            data.forEach(donor => {
                list.innerHTML += `
                    <div class="donation-item">
                        <h3>${donor.name}</h3>
                        <p><b>Email:</b> ${donor.email}</p>
                        <p><b>Phone:</b> ${donor.phone}</p>
                        <p><b>Address:</b> ${donor.address}</p>
                        <p><b>Donor ID:</b> ${donor.id}</p>
                    </div>
                `;
            });
        })
        .catch(error => {
            document.getElementById("donorsList").innerHTML =
                "Error loading donors";
            console.log(error);
        });
}

// ---------------- VOLUNTEER FUNCTIONS ----------------

function addVolunteer() {
    const name = document.getElementById("volunteerName").value.trim();
    const email = document.getElementById("volunteerEmail").value.trim();
    const phone = document.getElementById("volunteerPhone").value.trim();
    const area = document.getElementById("volunteerArea").value.trim();
    const availability = document.getElementById("volunteerAvailability").value.trim();

    if (
        name === "" ||
        email === "" ||
        phone === "" ||
        area === "" ||
        availability === ""
    ) {
        document.getElementById("volunteerResult").innerText =
            "Please fill all volunteer fields before adding.";
        return;
    }

    const volunteer = {
        name: name,
        email: email,
        phone: phone,
        area: area,
        availability: availability
    };

    fetch(`${API_URL}/volunteers`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(volunteer)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to add volunteer");
        }
        return response.json();
    })
    .then(data => {
        document.getElementById("volunteerResult").innerText =
            "Volunteer added successfully!";

        document.getElementById("volunteerName").value = "";
        document.getElementById("volunteerEmail").value = "";
        document.getElementById("volunteerPhone").value = "";
        document.getElementById("volunteerArea").value = "";
        document.getElementById("volunteerAvailability").value = "";

        getVolunteers();
    })
    .catch(error => {
        document.getElementById("volunteerResult").innerText =
            "Error adding volunteer. Please check backend.";
        console.log(error);
    });
}

function getVolunteers() {
    fetch(`${API_URL}/volunteers`)
        .then(response => response.json())
        .then(data => {
            const list = document.getElementById("volunteersList");
            list.innerHTML = "";

            data.forEach(volunteer => {
                list.innerHTML += `
                    <div class="donation-item">
                        <h3>${volunteer.name}</h3>
                        <p><b>Email:</b> ${volunteer.email}</p>
                        <p><b>Phone:</b> ${volunteer.phone}</p>
                        <p><b>Area:</b> ${volunteer.area}</p>
                        <p><b>Availability:</b> ${volunteer.availability}</p>
                        <p><b>Volunteer ID:</b> ${volunteer.id}</p>
                    </div>
                `;
            });
        })
        .catch(error => {
            document.getElementById("volunteersList").innerHTML =
                "Error loading volunteers";
            console.log(error);
        });
}

// ---------------- DONATION FUNCTIONS ----------------

function addDonation() {
    const foodType = document.getElementById("foodType").value.trim();
    const quantity = document.getElementById("quantity").value.trim();
    const pickupLocation = document.getElementById("pickupLocation").value.trim();
    const pickupTime = document.getElementById("pickupTime").value.trim();
    const expiryTime = document.getElementById("expiryTime").value.trim();
    const donorId = document.getElementById("donorId").value.trim();

    if (
        foodType === "" ||
        quantity === "" ||
        pickupLocation === "" ||
        pickupTime === "" ||
        expiryTime === "" ||
        donorId === ""
    ) {
        document.getElementById("donationResult").innerText =
            "Please fill all fields before adding donation.";
        return;
    }

    const donation = {
        food_type: foodType,
        quantity: quantity,
        pickup_location: pickupLocation,
        pickup_time: pickupTime,
        expiry_time: expiryTime,
        donor_id: donorId,
        status: "Available"
    };

    fetch(`${API_URL}/donations`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(donation)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to add donation");
        }
        return response.json();
    })
    .then(data => {
        document.getElementById("donationResult").innerText =
            "Donation added successfully!";

        document.getElementById("foodType").value = "";
        document.getElementById("quantity").value = "";
        document.getElementById("pickupLocation").value = "";
        document.getElementById("pickupTime").value = "";
        document.getElementById("expiryTime").value = "";
        document.getElementById("donorId").value = "";

        getDonations();
    })
    .catch(error => {
        document.getElementById("donationResult").innerText =
            "Error adding donation. Please check backend.";
        console.log(error);
    });
}

function getDonations() {
    fetch(`${API_URL}/donations`)
        .then(response => response.json())
        .then(data => {
            const list = document.getElementById("donationsList");
            list.innerHTML = "";

            data.forEach(donation => {
                list.innerHTML += `
                    <div class="donation-item">
                        <h3>${donation.food_type}</h3>
                        <p><b>Quantity:</b> ${donation.quantity}</p>
                        <p><b>Pickup Location:</b> ${donation.pickup_location}</p>
                        <p><b>Pickup Time:</b> ${donation.pickup_time}</p>
                        <p><b>Expiry Time:</b> ${donation.expiry_time}</p>
                        <p><b>Status:</b> ${donation.status}</p>
                        <p><b>Donor ID:</b> ${donation.donor_id}</p>
                    </div>
                `;
            });
        })
        .catch(error => {
            document.getElementById("donationsList").innerHTML =
                "Error loading donations";
            console.log(error);
        });
}

// ---------------- SEARCH FUNCTION ----------------

function searchDonations() {
    const searchBy = document.getElementById("searchBy").value;
    const query = document.getElementById("searchQuery").value.trim();

    if (query === "") {
        document.getElementById("searchResults").innerHTML =
            "Please enter something to search.";
        return;
    }

    fetch(`${API_URL}/search-donations?search_by=${searchBy}&query=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(result => {
            const list = document.getElementById("searchResults");
            list.innerHTML = "";

            if (!result.data || result.data.length === 0) {
                list.innerHTML = "<p>No donations found.</p>";
                return;
            }

            result.data.forEach(donation => {
                list.innerHTML += `
                    <div class="donation-item">
                        <h3>${donation.food_type}</h3>
                        <p><b>Quantity:</b> ${donation.quantity}</p>
                        <p><b>Pickup Location:</b> ${donation.pickup_location}</p>
                        <p><b>Pickup Time:</b> ${donation.pickup_time}</p>
                        <p><b>Expiry Time:</b> ${donation.expiry_time}</p>
                        <p><b>Status:</b> ${donation.status}</p>
                        <p><b>Donor ID:</b> ${donation.donor_id}</p>
                    </div>
                `;
            });
        })
        .catch(error => {
            document.getElementById("searchResults").innerHTML =
                "Error searching donations.";
            console.log(error);
        });
}

// ---------------- LOGIN FUNCTION ----------------

function loginUser() {
    const email = document.getElementById("loginEmail").value.trim();
    const phone = document.getElementById("loginPhone").value.trim();
    const password = document.getElementById("loginPassword").value.trim();
    const role = document.getElementById("loginRole").value;

    if (email === "" || phone === "" || password === "" || role === "") {
        document.getElementById("loginResult").innerText =
            "Please enter email, phone number, password, and role.";
        return;
    }

    const loginData = {
        email: email,
        phone: phone,
        password: password,
        role: role
    };

    fetch(`${API_URL}/login`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(loginData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Invalid login details");
        }
        return response.json();
    })
    .then(data => {
        document.getElementById("loginResult").innerText =
            "Login successful! Redirecting...";

        localStorage.setItem("user_id", data.user_id);
        localStorage.setItem("user_name", data.name);
        localStorage.setItem("user_email", data.email);
        localStorage.setItem("user_phone", data.phone);
        localStorage.setItem("user_role", data.role.toLowerCase());

        setTimeout(() => {
            window.location.href = "index.html";
        }, 1000);
    })
    .catch(error => {
        document.getElementById("loginResult").innerText =
            "Invalid email, phone number, password, or role.";
        console.log(error);
    });
}

// ---------------- REGISTER FUNCTION ----------------

function registerUser() {
    const name = document.getElementById("registerName").value.trim();
    const email = document.getElementById("registerEmail").value.trim();
    const phone = document.getElementById("registerPhone").value.trim();
    const password = document.getElementById("registerPassword").value.trim();
    const role = document.getElementById("registerRole").value;

    if (name === "" || email === "" || phone === "" || password === "" || role === "") {
        document.getElementById("registerResult").innerText =
            "Please fill all fields before registering.";
        return;
    }

    const registerData = {
        name: name,
        email: email,
        phone: phone,
        password: password,
        role: role
    };

    fetch(`${API_URL}/register`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(registerData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Registration failed");
        }
        return response.json();
    })
    .then(data => {
        document.getElementById("registerResult").innerText =
            "Registration successful! Redirecting to login...";

        document.getElementById("registerName").value = "";
        document.getElementById("registerEmail").value = "";
        document.getElementById("registerPhone").value = "";
        document.getElementById("registerPassword").value = "";

        setTimeout(() => {
            window.location.href = "login.html";
        }, 1000);
    })
    .catch(error => {
        document.getElementById("registerResult").innerText =
            "Registration failed. Email or phone may already exist.";
        console.log(error);
    });
}

// ---------------- LOGGED-IN USER + ROLE ACCESS ----------------

function showLoggedInUser() {
    const userInfo = document.getElementById("userInfo");

    // This prevents login.html and register.html from breaking
    if (!userInfo) {
        return;
    }

    const userName = localStorage.getItem("user_name");
    const userRole = localStorage.getItem("user_role");

    if (userName && userRole) {
        userInfo.innerHTML = `
            <p><b>Welcome:</b> ${userName}</p>
            <p><b>Role:</b> ${userRole}</p>
        `;

        applyRoleAccess(userRole.toLowerCase());
    } else {
        window.location.href = "login.html";
    }
}

function applyRoleAccess(role) {
    const adminSections = document.querySelectorAll(".admin-section");
    const donorSections = document.querySelectorAll(".donor-section");
    const commonSections = document.querySelectorAll(".common-section");

    adminSections.forEach(section => section.style.display = "none");
    donorSections.forEach(section => section.style.display = "none");
    commonSections.forEach(section => section.style.display = "none");

    if (role === "admin") {
        adminSections.forEach(section => section.style.display = "block");
        donorSections.forEach(section => section.style.display = "block");
        commonSections.forEach(section => section.style.display = "block");
    } else if (role === "donor") {
        donorSections.forEach(section => section.style.display = "block");
        commonSections.forEach(section => section.style.display = "block");
    } else if (role === "volunteer") {
        commonSections.forEach(section => section.style.display = "block");
    }
}

// ---------------- LOGOUT FUNCTION ----------------

function logoutUser() {
    localStorage.removeItem("user_id");
    localStorage.removeItem("user_name");
    localStorage.removeItem("user_email");
    localStorage.removeItem("user_role");

    window.location.href = "login.html";
}

// Run this when page loads
showLoggedInUser();