from pydantic import BaseModel
from typing import Optional

class Donor(BaseModel):
    name: str
    email: str
    phone: str
    address: str

class Volunteer(BaseModel):
    name: str
    email: str
    phone: str
    area: str
    availability: str
class FoodDonation(BaseModel):
    donor_id: str
    food_type: str
    quantity: str
    pickup_location: str
    pickup_time: str
    expiry_time: str
    status: str = "Available"
    volunteer_id: Optional[str] = None


class DonationStatusUpdate(BaseModel):
    status: str

class UserRegister(BaseModel):
    name: str
    email: str
    phone: str
    password: str
    role: str

class UserLogin(BaseModel):
    email: str
    phone: str
    password: str
    role: str