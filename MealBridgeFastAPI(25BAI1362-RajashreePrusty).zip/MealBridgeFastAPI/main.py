from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI, HTTPException
from bson import ObjectId
from pydantic import BaseModel
from passlib.context import CryptContext

from database import client, donor_collection, volunteer_collection, donation_collection, user_collection
from models import Donor, Volunteer, FoodDonation,DonationStatusUpdate, UserRegister, UserLogin

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

app = FastAPI(
    title="MealBridge",
    description="A Food Donation and Volunteer Coordination System built using FastAPI and MongoDB.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/register", tags=["Authentication"], summary="Register User")
def register_user(user: UserRegister):
    allowed_roles = ["donor", "volunteer", "admin"]

    if len(user.password.encode("utf-8")) > 72:
        raise HTTPException(
            status_code=400,
            detail="Password is too long. Please use a password under 72 characters."
        )

    if user.role.lower() not in allowed_roles:
        raise HTTPException(
            status_code=400,
            detail="Invalid role. Role must be donor, volunteer, or admin."
        )

    existing_email = user_collection.find_one({
        "email": user.email
    })

    if existing_email:
        raise HTTPException(
            status_code=400,
            detail="This email is already registered. Please use another email."
        )

    existing_phone = user_collection.find_one({
        "phone": user.phone
    })

    if existing_phone:
        raise HTTPException(
            status_code=400,
            detail="This phone number is already registered. Please use another phone number."
        )

    hashed_password = pwd_context.hash(user.password)

    new_user = {
        "name": user.name,
        "email": user.email,
        "phone": user.phone,
        "password": hashed_password,
        "role": user.role.lower()
    }

    result = user_collection.insert_one(new_user)

    return {
        "message": "User registered successfully",
        "user_id": str(result.inserted_id),
        "role": user.role.lower()
    }

@app.post("/login", tags=["Authentication"], summary="Login User")
def login_user(user: UserLogin):
    existing_user = user_collection.find_one({
        "email": user.email,
        "phone": user.phone,
        "role": user.role.lower()
    })

    if not existing_user:
        raise HTTPException(
            status_code=404,
            detail="User not found. Please check email, phone number, and role."
        )

    if not pwd_context.verify(user.password, existing_user["password"]):
        raise HTTPException(
            status_code=401,
            detail="Invalid password."
        )

    return {
        "message": "Login successful",
        "user_id": str(existing_user["_id"]),
        "name": existing_user["name"],
        "email": existing_user["email"],
        "phone": existing_user["phone"],
        "role": existing_user["role"]
    }


def donor_serializer(donor):
    return {
        "id": str(donor["_id"]),
        "name": donor["name"],
        "email": donor["email"],
        "phone": donor["phone"],
        "address": donor["address"]
    }

def volunteer_serializer(volunteer):
    return {
        "id": str(volunteer["_id"]),
        "name": volunteer["name"],
        "email": volunteer["email"],
        "phone": volunteer["phone"],
        "area": volunteer["area"],
        "availability": volunteer["availability"]
    }

def donation_serializer(donation):
    return {
        "id": str(donation["_id"]),
        "donor_id": donation["donor_id"],
        "food_type": donation["food_type"],
        "quantity": donation["quantity"],
        "pickup_location": donation["pickup_location"],
        "pickup_time": donation["pickup_time"],
        "expiry_time": donation["expiry_time"],
        "status": donation["status"],
        "volunteer_id": donation.get("volunteer_id")
    }

@app.get("/", tags=["System"], summary="Home")
def home():
    return {"message": "Welcome to MealBridge API"}


@app.get("/check-db", tags=["System"], summary="Check Database Connection")
def check_database():
    try:
        client.admin.command("ping")
        return {"message": "MongoDB connected successfully"}
    except Exception as e:
        return {"error": str(e)}


@app.post("/donors", tags=["Donors"], summary="Add Donor")
def add_donor(donor: Donor):
    donor_data = donor.model_dump()
    result = donor_collection.insert_one(donor_data)

    return {
        "message": "Donor added successfully",
        "donor_id": str(result.inserted_id)
    }


@app.get("/donors", tags=["Donors"], summary="Get All Donors")
def get_all_donors():
    donors = donor_collection.find()
    return [donor_serializer(donor) for donor in donors]


@app.get("/donors/{donor_id}", tags=["Donors"], summary="Get Donor by ID")
def get_donor(donor_id: str):
    donor = donor_collection.find_one({"_id": ObjectId(donor_id)})

    if donor:
        return donor_serializer(donor)

    raise HTTPException(status_code=404, detail="Donor not found")


@app.put("/donors/{donor_id}", tags=["Donors"], summary="Update Donor")
def update_donor(donor_id: str, donor: Donor):
    updated_data = donor.model_dump()

    result = donor_collection.update_one(
        {"_id": ObjectId(donor_id)},
        {"$set": updated_data}
    )

    if result.modified_count == 1:
        return {"message": "Donor updated successfully"}

    raise HTTPException(status_code=404, detail="Donor not found or no changes made")


@app.delete("/donors/{donor_id}", tags=["Donors"], summary="Delete Donor")
def delete_donor(donor_id: str):
    result = donor_collection.delete_one({"_id": ObjectId(donor_id)})

    if result.deleted_count == 1:
        return {"message": "Donor deleted successfully"}

    raise HTTPException(status_code=404, detail="Donor not found")

@app.post("/volunteers", tags=["Volunteers"], summary="Add Volunteer")
def add_volunteer(volunteer: Volunteer):
    volunteer_data = volunteer.model_dump()
    result = volunteer_collection.insert_one(volunteer_data)

    return {
        "message": "Volunteer added successfully",
        "volunteer_id": str(result.inserted_id)
    }


@app.get("/volunteers", tags=["Volunteers"], summary="Get All Volunteers")
def get_all_volunteers():
    volunteers = volunteer_collection.find()
    return [volunteer_serializer(volunteer) for volunteer in volunteers]


@app.get("/volunteers/{volunteer_id}", tags=["Volunteers"], summary="Get Volunteer by ID")
def get_volunteer(volunteer_id: str):
    volunteer = volunteer_collection.find_one({"_id": ObjectId(volunteer_id)})

    if volunteer:
        return volunteer_serializer(volunteer)

    raise HTTPException(status_code=404, detail="Volunteer not found")


@app.put("/volunteers/{volunteer_id}", tags=["Volunteers"], summary="Update Volunteer")
def update_volunteer(volunteer_id: str, volunteer: Volunteer):
    updated_data = volunteer.model_dump()

    result = volunteer_collection.update_one(
        {"_id": ObjectId(volunteer_id)},
        {"$set": updated_data}
    )

    if result.modified_count == 1:
        return {"message": "Volunteer updated successfully"}

    raise HTTPException(status_code=404, detail="Volunteer not found or no changes made")


@app.delete("/volunteers/{volunteer_id}", tags=["Volunteers"], summary="Delete Volunteer")
def delete_volunteer(volunteer_id: str):
    result = volunteer_collection.delete_one({"_id": ObjectId(volunteer_id)})

    if result.deleted_count == 1:
        return {"message": "Volunteer deleted successfully"}

    raise HTTPException(status_code=404, detail="Volunteer not found")

@app.post("/donations", tags=["Donations"], summary="Add Food Donation")
def add_donation(donation: FoodDonation):
    donor = donor_collection.find_one({"_id": ObjectId(donation.donor_id)})

    if not donor:
        raise HTTPException(status_code=404, detail="Donor not found")

    donation_data = donation.model_dump()
    result = donation_collection.insert_one(donation_data)

    return {
        "message": "Food donation added successfully",
        "donation_id": str(result.inserted_id)
    }


@app.get("/donations", tags=["Donations"], summary="Get All Donations")
def get_all_donations():
    donations = donation_collection.find()
    return [donation_serializer(donation) for donation in donations]


@app.get("/donations/available", tags=["Donations"], summary="Get Available Donations")
def get_available_donations():
    donations = donation_collection.find({"status": "Available"})
    return [donation_serializer(donation) for donation in donations]


@app.get("/donations/{donation_id}", tags=["Donations"], summary="Get Donation by ID")
def get_donation(donation_id: str):
    donation = donation_collection.find_one({"_id": ObjectId(donation_id)})

    if donation:
        return donation_serializer(donation)

    raise HTTPException(status_code=404, detail="Donation not found")


@app.put("/donations/{donation_id}", tags=["Donations"], summary="Update Donation")
def update_donation(donation_id: str, donation: FoodDonation):
    updated_data = donation.model_dump()

    result = donation_collection.update_one(
        {"_id": ObjectId(donation_id)},
        {"$set": updated_data}
    )

    if result.modified_count == 1:
        return {"message": "Donation updated successfully"}

    raise HTTPException(status_code=404, detail="Donation not found or no changes made")


@app.put("/donations/{donation_id}/assign-volunteer/{volunteer_id}", tags=["Donations"], summary="Assign Volunteer to Donation")
def assign_volunteer(donation_id: str, volunteer_id: str):
    donation = donation_collection.find_one({"_id": ObjectId(donation_id)})
    volunteer = volunteer_collection.find_one({"_id": ObjectId(volunteer_id)})

    if not donation:
        raise HTTPException(status_code=404, detail="Donation not found")

    if not volunteer:
        raise HTTPException(status_code=404, detail="Volunteer not found")

    result = donation_collection.update_one(
        {"_id": ObjectId(donation_id)},
        {
            "$set": {
                "volunteer_id": volunteer_id,
                "status": "Assigned"
            }
        }
    )

    if result.modified_count == 1:
        return {"message": "Volunteer assigned successfully"}

    return {"message": "Volunteer already assigned or no changes made"}


@app.put("/donations/{donation_id}/status", tags=["Donations"], summary="Update Donation Status")
def update_donation_status(donation_id: str, status_update: DonationStatusUpdate):
    if not ObjectId.is_valid(donation_id):
        raise HTTPException(status_code=400, detail="Invalid donation ID")

    result = donation_collection.update_one(
        {"_id": ObjectId(donation_id)},
        {"$set": {"status": status_update.status}}
    )

    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Donation not found")

    if result.modified_count == 0:
        return {"message": "Donation status is already the same"}

    return {"message": "Donation status updated successfully"}


@app.delete("/donations/{donation_id}", tags=["Donations"], summary="Delete Donation")
def delete_donation(donation_id: str):
    result = donation_collection.delete_one({"_id": ObjectId(donation_id)})

    if result.deleted_count == 1:
        return {"message": "Donation deleted successfully"}

    raise HTTPException(status_code=404, detail="Donation not found")

@app.get("/search-donations", tags=["Search"], summary="Search Donations")
def search_donations(search_by: str, query: str):
    if search_by == "food_type":
        search_filter = {
            "food_type": {"$regex": query, "$options": "i"}
        }

    elif search_by == "location":
        search_filter = {
            "pickup_location": {"$regex": query, "$options": "i"}
        }

    elif search_by == "status":
        search_filter = {
            "status": {"$regex": query, "$options": "i"}
        }

    elif search_by == "query":
        search_filter = {
            "$or": [
                {"food_type": {"$regex": query, "$options": "i"}},
                {"pickup_location": {"$regex": query, "$options": "i"}},
                {"status": {"$regex": query, "$options": "i"}},
                {"quantity": {"$regex": query, "$options": "i"}}
            ]
        }

    else:
        return {"message": "Invalid search type"}

    donations = donation_collection.find(search_filter)

    result = []

    for donation in donations:
        donation["id"] = str(donation["_id"])
        del donation["_id"]
        result.append(donation)

    if len(result) == 0:
        return {"message": "No donations found", "data": []}

    return {"message": "Donations found", "data": result}

    return [donation_serializer(donation) for donation in donations]


@app.delete("/clear-donations", tags=["Delete Operations"], summary="Clear All Donations")
def clear_all_donations():
    result = donation_collection.delete_many({})

    return {
        "message": "All donation records cleared successfully",
        "deleted_count": result.deleted_count
    }


